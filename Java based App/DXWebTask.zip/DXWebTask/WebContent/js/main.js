var angularTodo = angular.module('angularTodo', []);

function mainController($scope, $http) {
	$scope.formData = {};

	// GET Method of AngularJS to invoke the rest service
	$http.get('http://localhost:8080/DXWebTask/rest/resource')
		.success(function(data) {
			$scope.todos = data;
			console.log(data);
		})
		.error(function(data) {
			console.log('Error: ' + data);
		});

	// POST Method of AngularJS to invoke the rest service
	$scope.createTodo = function(){
		$http.post('http://localhost:8080/DXWebTask/rest/resource', $scope.formData)
			.success(function(data) {
				$scope.formData = {};
				$scope.todos = data;
				console.log(data);
			})
			.error(function(data) {
				console.log('Error:' + data);
			});
	};

}