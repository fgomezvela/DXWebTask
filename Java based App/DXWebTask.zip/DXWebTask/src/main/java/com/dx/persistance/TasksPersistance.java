package com.dx.persistance;

import java.util.ArrayList;

import com.dx.rest.jersey.Task;
/**
 * Class developved to simulate the task persistance
 * 
 * @author Francisco A. G�mez Vela
 *
 */
public class TasksPersistance {
	private ArrayList<Task> tasks;
	private static TasksPersistance instance = null;

	private TasksPersistance() {
		tasks = new ArrayList<Task>();
		// Initialize the Task List
		Task t = Task.loadTask("");
		Task t2 = Task.loadTask("");
		tasks.add(t);
		tasks.add(t2);
	}
	
	public static TasksPersistance getInstance(){
		if(instance == null)
			instance = new  TasksPersistance();
		
		return instance;
			
	}

	public ArrayList<Task> getTasks() {
		return tasks;
	}

	public void setTask(Task task) {
		this.tasks.add(task);
	}
	
	

}
