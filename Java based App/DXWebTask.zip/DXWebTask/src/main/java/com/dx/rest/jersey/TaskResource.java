package com.dx.rest.jersey;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.dx.persistance.TasksPersistance;
import com.google.gson.Gson;
/**
 * Class which contains the REST Api
 * 
 * @author Francisco A. G�mez Vela
 *
 */
@Path("/resource")
public class TaskResource {
	//List of Task
	TasksPersistance persistance = TasksPersistance.getInstance();
	//JASON Parser
	Gson gson = new Gson();
	
	//GET Method
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getTasks() {
		//Show all task stored
		return gson.toJson(persistance.getTasks());
	}
	
	//POST Method
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String setTask(String content ) {
		Task t2 = Task.loadTask("");
		t2.setContent("New POST task");
		persistance.getTasks().add(t2);
		return gson.toJson(persistance.getTasks());
	}
}
