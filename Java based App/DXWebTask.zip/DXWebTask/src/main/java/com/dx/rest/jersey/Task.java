package com.dx.rest.jersey;

/**
 * Simple Class for a TODO object
 * @author Francisco A. G�mez Vela
 *
 */
public class Task {
	private int id=-1;
	private String content;
	
	public Task(int id, String content) {
		super();
		this.id = id;
		this.content = content;
	}

	public Task() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public static Task loadTask(String id) {

	
		Task t = RandomTask();
	
		return t;
	}

	private static Task RandomTask() {
		// TODO Auto-generated method stub
		int randomNum = 0 + (int)(Math.random()*100); 
		return new Task(randomNum,"Content for a GET Task");
	}

	public static void saveTask(Task t) {
		System.out.println("New Task created");	
		
	}
}
